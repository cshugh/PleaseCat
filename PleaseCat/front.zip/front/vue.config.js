module.exports = {
    'transpileDependencies': [
        'vuetify'
    ],
    lintOnSave: false
}
<template>
<div>
  <header>
    <h1>뉴스피드</h1>
  </header>
  <div id="testhi">
      <h2>하이하이</h2>
</div>
<footer>
    <img class="Img" v-bind:src="homeImg"/>
    <img class="Img" v-bind:src="location"/>
    <img class="Img" v-bind:src="plus"/>
    <img class="Img" v-bind:src="search"/>
    <img class="Img" v-bind:src="profile"/>
</footer>

</div>
</template>

<script>
import '../../assets/css/style.css'
// import Vue from 'vue'
export default {
  created() {
    this.homeImg = require('../../assets/images/home.jpeg');
    this.location = require('../../assets/images/home.jpeg');
    this.plus = require('../../assets/images/plus.png');
    this.search = require('../../assets/images/search.jpg');
    this.profile = require('../../assets/images/profile.png');
  },
  data: () => {
    return {
      email: "",
      homeImg: '',
      location: '',
      plus: '',
      search: '',
      profile: ''
    };
  }
};
</script>
